import Home from "./pages/home";

/* eslint-disable react/no-unescaped-entities */
const App = () => {
  return (
    <>
      <Home/>
    </>
  );
};

export default App;
